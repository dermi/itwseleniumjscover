#java -jar target/dist/JSCover.jar -ws --branch --document-root=doc/example --report-dir=target
java -jar ./JSCover-all.jar -ws --branch --document-root=. --report-dir=target
